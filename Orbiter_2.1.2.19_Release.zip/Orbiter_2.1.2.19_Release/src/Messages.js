//==============================================================================
// MESSAGE CONSTANTS
//==============================================================================
/** @class */
net.user1.orbiter.Messages = new Object();
/** @constant */
net.user1.orbiter.Messages.CLIENT_HEARTBEAT = "CLIENT_HEARTBEAT";
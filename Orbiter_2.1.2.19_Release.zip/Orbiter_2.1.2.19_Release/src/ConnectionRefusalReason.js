//==============================================================================
// CONNECTION REFUSAL REASON CONSTANTS
//==============================================================================
/** @class */
net.user1.orbiter.ConnectionRefusalReason = new Object();
/** @constant */
net.user1.orbiter.ConnectionRefusalReason.BANNED = "BANNED";

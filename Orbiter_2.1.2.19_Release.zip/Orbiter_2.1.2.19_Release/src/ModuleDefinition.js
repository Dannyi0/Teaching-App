//==============================================================================
// CLASS DECLARATION
//==============================================================================
/**
 * @class
 */
net.user1.orbiter.ModuleDefinition = function (id, type, source) {
  this.id = id;
  this.type = type;
  this.source = source;
};

//==============================================================================
// CLASS DECLARATION
//==============================================================================
/** 
 * @class
 */
net.user1.utils.CacheNode = function () {
  /** @field */
  this.next;
  /** @field */
  this.prev;
  /** @field */
  this.key;
  /** @field */
  this.value;
};

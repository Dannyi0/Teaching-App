//==============================================================================
// PACKAGE DECLARATIONS
//==============================================================================
net.user1.utils.createPackage("net.user1.logger");
net.user1.utils.createPackage("net.user1.events");
net.user1.utils.createPackage("net.user1.orbiter");
net.user1.utils.createPackage("net.user1.orbiter.filters");
net.user1.utils.createPackage("net.user1.orbiter.snapshot");
net.user1.utils.createPackage("net.user1.orbiter.upc");
net.user1.utils.createPackage("net.user1.utils");
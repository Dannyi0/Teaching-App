//==============================================================================
// MODULE TYPE CONSTANTS
//==============================================================================
/** @class */
net.user1.orbiter.ModuleType = new Object();
/** @constant */
net.user1.orbiter.ModuleType.CLASS = "class";
/** @constant */
net.user1.orbiter.ModuleType.SCRIPT = "script";
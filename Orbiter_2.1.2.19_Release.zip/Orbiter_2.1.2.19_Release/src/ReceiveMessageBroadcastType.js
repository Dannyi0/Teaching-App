//==============================================================================
// RECEIVE MESSAGE BROADCAST TYPE CONSTANTS
//==============================================================================
/** @class
    @private */
net.user1.orbiter.ReceiveMessageBroadcastType = new Object();
net.user1.orbiter.ReceiveMessageBroadcastType.TO_SERVER  = "0";
net.user1.orbiter.ReceiveMessageBroadcastType.TO_ROOMS   = "1";
net.user1.orbiter.ReceiveMessageBroadcastType.TO_CLIENTS = "2";

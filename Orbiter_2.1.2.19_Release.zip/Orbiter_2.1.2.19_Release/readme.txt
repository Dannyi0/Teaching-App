================================================================================
Orbiter 2.1.2.19 Release
================================================================================
Release Date: 9-April-2016

Orbiter is a full-featured JavaScript framework for creating 
connected web applications and content. With Orbiter, you can create
chat, whiteboards, real-time multiplayer games, meeting applications, 
collaborative editing tools, and shared interfaces that all run directly in
your web browser. 

Complete documentation for this release is available at:
http://www.unionplatform.com/

        For more information, please visit www.unionplatform.com.

              (c) Copyright USER1 Subsystems Corporation 